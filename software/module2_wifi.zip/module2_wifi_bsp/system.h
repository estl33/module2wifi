/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'nios2_qsys_0' in SOPC Builder design 'nios_system'
 * SOPC Builder design path: ../../nios_system.sopcinfo
 *
 * Generated: Wed Mar 21 10:40:55 PDT 2018
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2_qsys"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x00001820
#define ALT_CPU_CPU_FREQ 50000000u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x00000000
#define ALT_CPU_CPU_IMPLEMENTATION "small"
#define ALT_CPU_DATA_ADDR_WIDTH 0x1c
#define ALT_CPU_DCACHE_LINE_SIZE 0
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_DCACHE_SIZE 0
#define ALT_CPU_EXCEPTION_ADDR 0x08000020
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 50000000
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 1
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 1
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 32
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 5
#define ALT_CPU_ICACHE_SIZE 4096
#define ALT_CPU_INST_ADDR_WIDTH 0x1c
#define ALT_CPU_NAME "nios2_qsys_0"
#define ALT_CPU_RESET_ADDR 0x08000000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x00001820
#define NIOS2_CPU_FREQ 50000000u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x00000000
#define NIOS2_CPU_IMPLEMENTATION "small"
#define NIOS2_DATA_ADDR_WIDTH 0x1c
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_EXCEPTION_ADDR 0x08000020
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 1
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 1
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 32
#define NIOS2_ICACHE_LINE_SIZE_LOG2 5
#define NIOS2_ICACHE_SIZE 4096
#define NIOS2_INST_ADDR_WIDTH 0x1c
#define NIOS2_RESET_ADDR 0x08000000


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_TIMER
#define __ALTERA_NIOS2_QSYS
#define __ALTERA_UP_AVALON_CHARACTER_LCD
#define __ALTERA_UP_AVALON_TO_EXTERNAL_BUS_BRIDGE


/*
 * HEX0_1 configuration
 *
 */

#define ALT_MODULE_CLASS_HEX0_1 altera_avalon_pio
#define HEX0_1_BASE 0x2030
#define HEX0_1_BIT_CLEARING_EDGE_REGISTER 0
#define HEX0_1_BIT_MODIFYING_OUTPUT_REGISTER 0
#define HEX0_1_CAPTURE 0
#define HEX0_1_DATA_WIDTH 8
#define HEX0_1_DO_TEST_BENCH_WIRING 0
#define HEX0_1_DRIVEN_SIM_VALUE 0
#define HEX0_1_EDGE_TYPE "NONE"
#define HEX0_1_FREQ 50000000
#define HEX0_1_HAS_IN 0
#define HEX0_1_HAS_OUT 1
#define HEX0_1_HAS_TRI 0
#define HEX0_1_IRQ -1
#define HEX0_1_IRQ_INTERRUPT_CONTROLLER_ID -1
#define HEX0_1_IRQ_TYPE "NONE"
#define HEX0_1_NAME "/dev/HEX0_1"
#define HEX0_1_RESET_VALUE 0
#define HEX0_1_SPAN 16
#define HEX0_1_TYPE "altera_avalon_pio"


/*
 * HEX2_3 configuration
 *
 */

#define ALT_MODULE_CLASS_HEX2_3 altera_avalon_pio
#define HEX2_3_BASE 0x2040
#define HEX2_3_BIT_CLEARING_EDGE_REGISTER 0
#define HEX2_3_BIT_MODIFYING_OUTPUT_REGISTER 0
#define HEX2_3_CAPTURE 0
#define HEX2_3_DATA_WIDTH 8
#define HEX2_3_DO_TEST_BENCH_WIRING 0
#define HEX2_3_DRIVEN_SIM_VALUE 0
#define HEX2_3_EDGE_TYPE "NONE"
#define HEX2_3_FREQ 50000000
#define HEX2_3_HAS_IN 0
#define HEX2_3_HAS_OUT 1
#define HEX2_3_HAS_TRI 0
#define HEX2_3_IRQ -1
#define HEX2_3_IRQ_INTERRUPT_CONTROLLER_ID -1
#define HEX2_3_IRQ_TYPE "NONE"
#define HEX2_3_NAME "/dev/HEX2_3"
#define HEX2_3_RESET_VALUE 0
#define HEX2_3_SPAN 16
#define HEX2_3_TYPE "altera_avalon_pio"


/*
 * HEX4_5 configuration
 *
 */

#define ALT_MODULE_CLASS_HEX4_5 altera_avalon_pio
#define HEX4_5_BASE 0x2050
#define HEX4_5_BIT_CLEARING_EDGE_REGISTER 0
#define HEX4_5_BIT_MODIFYING_OUTPUT_REGISTER 0
#define HEX4_5_CAPTURE 0
#define HEX4_5_DATA_WIDTH 8
#define HEX4_5_DO_TEST_BENCH_WIRING 0
#define HEX4_5_DRIVEN_SIM_VALUE 0
#define HEX4_5_EDGE_TYPE "NONE"
#define HEX4_5_FREQ 50000000
#define HEX4_5_HAS_IN 0
#define HEX4_5_HAS_OUT 1
#define HEX4_5_HAS_TRI 0
#define HEX4_5_IRQ -1
#define HEX4_5_IRQ_INTERRUPT_CONTROLLER_ID -1
#define HEX4_5_IRQ_TYPE "NONE"
#define HEX4_5_NAME "/dev/HEX4_5"
#define HEX4_5_RESET_VALUE 0
#define HEX4_5_SPAN 16
#define HEX4_5_TYPE "altera_avalon_pio"


/*
 * PushButtons configuration
 *
 */

#define ALT_MODULE_CLASS_PushButtons altera_avalon_pio
#define PUSHBUTTONS_BASE 0x2060
#define PUSHBUTTONS_BIT_CLEARING_EDGE_REGISTER 0
#define PUSHBUTTONS_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PUSHBUTTONS_CAPTURE 0
#define PUSHBUTTONS_DATA_WIDTH 3
#define PUSHBUTTONS_DO_TEST_BENCH_WIRING 0
#define PUSHBUTTONS_DRIVEN_SIM_VALUE 0
#define PUSHBUTTONS_EDGE_TYPE "NONE"
#define PUSHBUTTONS_FREQ 50000000
#define PUSHBUTTONS_HAS_IN 1
#define PUSHBUTTONS_HAS_OUT 0
#define PUSHBUTTONS_HAS_TRI 0
#define PUSHBUTTONS_IRQ -1
#define PUSHBUTTONS_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PUSHBUTTONS_IRQ_TYPE "NONE"
#define PUSHBUTTONS_NAME "/dev/PushButtons"
#define PUSHBUTTONS_RESET_VALUE 0
#define PUSHBUTTONS_SPAN 16
#define PUSHBUTTONS_TYPE "altera_avalon_pio"


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "Cyclone V"
#define ALT_ENHANCED_INTERRUPT_API_PRESENT
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/jtag_uart_0"
#define ALT_STDERR_BASE 0x2020
#define ALT_STDERR_DEV jtag_uart_0
#define ALT_STDERR_IS_JTAG_UART
#define ALT_STDERR_PRESENT
#define ALT_STDERR_TYPE "altera_avalon_jtag_uart"
#define ALT_STDIN "/dev/jtag_uart_0"
#define ALT_STDIN_BASE 0x2020
#define ALT_STDIN_DEV jtag_uart_0
#define ALT_STDIN_IS_JTAG_UART
#define ALT_STDIN_PRESENT
#define ALT_STDIN_TYPE "altera_avalon_jtag_uart"
#define ALT_STDOUT "/dev/jtag_uart_0"
#define ALT_STDOUT_BASE 0x2020
#define ALT_STDOUT_DEV jtag_uart_0
#define ALT_STDOUT_IS_JTAG_UART
#define ALT_STDOUT_PRESENT
#define ALT_STDOUT_TYPE "altera_avalon_jtag_uart"
#define ALT_SYSTEM_NAME "nios_system"


/*
 * bass_out configuration
 *
 */

#define ALT_MODULE_CLASS_bass_out altera_avalon_pio
#define BASS_OUT_BASE 0x40
#define BASS_OUT_BIT_CLEARING_EDGE_REGISTER 0
#define BASS_OUT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define BASS_OUT_CAPTURE 0
#define BASS_OUT_DATA_WIDTH 4
#define BASS_OUT_DO_TEST_BENCH_WIRING 0
#define BASS_OUT_DRIVEN_SIM_VALUE 0
#define BASS_OUT_EDGE_TYPE "NONE"
#define BASS_OUT_FREQ 50000000
#define BASS_OUT_HAS_IN 0
#define BASS_OUT_HAS_OUT 1
#define BASS_OUT_HAS_TRI 0
#define BASS_OUT_IRQ -1
#define BASS_OUT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define BASS_OUT_IRQ_TYPE "NONE"
#define BASS_OUT_NAME "/dev/bass_out"
#define BASS_OUT_RESET_VALUE 0
#define BASS_OUT_SPAN 16
#define BASS_OUT_TYPE "altera_avalon_pio"


/*
 * character_lcd_0 configuration
 *
 */

#define ALT_MODULE_CLASS_character_lcd_0 altera_up_avalon_character_lcd
#define CHARACTER_LCD_0_BASE 0x20c0
#define CHARACTER_LCD_0_IRQ -1
#define CHARACTER_LCD_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define CHARACTER_LCD_0_NAME "/dev/character_lcd_0"
#define CHARACTER_LCD_0_SPAN 2
#define CHARACTER_LCD_0_TYPE "altera_up_avalon_character_lcd"


/*
 * hal configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER_0
#define ALT_TIMESTAMP_CLK none


/*
 * jtag_uart_0 configuration
 *
 */

#define ALT_MODULE_CLASS_jtag_uart_0 altera_avalon_jtag_uart
#define JTAG_UART_0_BASE 0x2020
#define JTAG_UART_0_IRQ 5
#define JTAG_UART_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define JTAG_UART_0_NAME "/dev/jtag_uart_0"
#define JTAG_UART_0_READ_DEPTH 64
#define JTAG_UART_0_READ_THRESHOLD 8
#define JTAG_UART_0_SPAN 8
#define JTAG_UART_0_TYPE "altera_avalon_jtag_uart"
#define JTAG_UART_0_WRITE_DEPTH 64
#define JTAG_UART_0_WRITE_THRESHOLD 8


/*
 * leds configuration
 *
 */

#define ALT_MODULE_CLASS_leds altera_avalon_pio
#define LEDS_BASE 0x2010
#define LEDS_BIT_CLEARING_EDGE_REGISTER 0
#define LEDS_BIT_MODIFYING_OUTPUT_REGISTER 0
#define LEDS_CAPTURE 0
#define LEDS_DATA_WIDTH 10
#define LEDS_DO_TEST_BENCH_WIRING 0
#define LEDS_DRIVEN_SIM_VALUE 0
#define LEDS_EDGE_TYPE "NONE"
#define LEDS_FREQ 50000000
#define LEDS_HAS_IN 0
#define LEDS_HAS_OUT 1
#define LEDS_HAS_TRI 0
#define LEDS_IRQ -1
#define LEDS_IRQ_INTERRUPT_CONTROLLER_ID -1
#define LEDS_IRQ_TYPE "NONE"
#define LEDS_NAME "/dev/leds"
#define LEDS_RESET_VALUE 0
#define LEDS_SPAN 16
#define LEDS_TYPE "altera_avalon_pio"


/*
 * pot configuration
 *
 */

#define ALT_MODULE_CLASS_pot altera_avalon_pio
#define POT_BASE 0x0
#define POT_BIT_CLEARING_EDGE_REGISTER 0
#define POT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define POT_CAPTURE 0
#define POT_DATA_WIDTH 16
#define POT_DO_TEST_BENCH_WIRING 0
#define POT_DRIVEN_SIM_VALUE 0
#define POT_EDGE_TYPE "NONE"
#define POT_FREQ 50000000
#define POT_HAS_IN 0
#define POT_HAS_OUT 1
#define POT_HAS_TRI 0
#define POT_IRQ -1
#define POT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define POT_IRQ_TYPE "NONE"
#define POT_NAME "/dev/pot"
#define POT_RESET_VALUE 0
#define POT_SPAN 16
#define POT_TYPE "altera_avalon_pio"


/*
 * sdram configuration
 *
 */

#define ALT_MODULE_CLASS_sdram altera_avalon_new_sdram_controller
#define SDRAM_BASE 0x8000000
#define SDRAM_CAS_LATENCY 3
#define SDRAM_CONTENTS_INFO
#define SDRAM_INIT_NOP_DELAY 0.0
#define SDRAM_INIT_REFRESH_COMMANDS 2
#define SDRAM_IRQ -1
#define SDRAM_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SDRAM_IS_INITIALIZED 1
#define SDRAM_NAME "/dev/sdram"
#define SDRAM_POWERUP_DELAY 100.0
#define SDRAM_REFRESH_PERIOD 7.8125
#define SDRAM_REGISTER_DATA_IN 1
#define SDRAM_SDRAM_ADDR_WIDTH 0x19
#define SDRAM_SDRAM_BANK_WIDTH 2
#define SDRAM_SDRAM_COL_WIDTH 10
#define SDRAM_SDRAM_DATA_WIDTH 16
#define SDRAM_SDRAM_NUM_BANKS 4
#define SDRAM_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_SDRAM_ROW_WIDTH 13
#define SDRAM_SHARED_DATA 0
#define SDRAM_SIM_MODEL_BASE 0
#define SDRAM_SPAN 67108864
#define SDRAM_STARVATION_INDICATOR 0
#define SDRAM_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_T_AC 5.4
#define SDRAM_T_MRD 3
#define SDRAM_T_RCD 15.0
#define SDRAM_T_RFC 70.0
#define SDRAM_T_RP 15.0
#define SDRAM_T_WR 14.0


/*
 * sound_in configuration
 *
 */

#define ALT_MODULE_CLASS_sound_in altera_avalon_pio
#define SOUND_IN_BASE 0x20
#define SOUND_IN_BIT_CLEARING_EDGE_REGISTER 0
#define SOUND_IN_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SOUND_IN_CAPTURE 0
#define SOUND_IN_DATA_WIDTH 16
#define SOUND_IN_DO_TEST_BENCH_WIRING 0
#define SOUND_IN_DRIVEN_SIM_VALUE 0
#define SOUND_IN_EDGE_TYPE "NONE"
#define SOUND_IN_FREQ 50000000
#define SOUND_IN_HAS_IN 1
#define SOUND_IN_HAS_OUT 0
#define SOUND_IN_HAS_TRI 0
#define SOUND_IN_IRQ -1
#define SOUND_IN_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SOUND_IN_IRQ_TYPE "NONE"
#define SOUND_IN_NAME "/dev/sound_in"
#define SOUND_IN_RESET_VALUE 0
#define SOUND_IN_SPAN 16
#define SOUND_IN_TYPE "altera_avalon_pio"


/*
 * sound_out configuration
 *
 */

#define ALT_MODULE_CLASS_sound_out altera_avalon_pio
#define SOUND_OUT_BASE 0x10
#define SOUND_OUT_BIT_CLEARING_EDGE_REGISTER 0
#define SOUND_OUT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SOUND_OUT_CAPTURE 0
#define SOUND_OUT_DATA_WIDTH 16
#define SOUND_OUT_DO_TEST_BENCH_WIRING 0
#define SOUND_OUT_DRIVEN_SIM_VALUE 0
#define SOUND_OUT_EDGE_TYPE "NONE"
#define SOUND_OUT_FREQ 50000000
#define SOUND_OUT_HAS_IN 0
#define SOUND_OUT_HAS_OUT 1
#define SOUND_OUT_HAS_TRI 0
#define SOUND_OUT_IRQ -1
#define SOUND_OUT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SOUND_OUT_IRQ_TYPE "NONE"
#define SOUND_OUT_NAME "/dev/sound_out"
#define SOUND_OUT_RESET_VALUE 0
#define SOUND_OUT_SPAN 16
#define SOUND_OUT_TYPE "altera_avalon_pio"


/*
 * switches configuration
 *
 */

#define ALT_MODULE_CLASS_switches altera_avalon_pio
#define SWITCHES_BASE 0x2000
#define SWITCHES_BIT_CLEARING_EDGE_REGISTER 0
#define SWITCHES_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SWITCHES_CAPTURE 0
#define SWITCHES_DATA_WIDTH 10
#define SWITCHES_DO_TEST_BENCH_WIRING 0
#define SWITCHES_DRIVEN_SIM_VALUE 0
#define SWITCHES_EDGE_TYPE "NONE"
#define SWITCHES_FREQ 50000000
#define SWITCHES_HAS_IN 1
#define SWITCHES_HAS_OUT 0
#define SWITCHES_HAS_TRI 0
#define SWITCHES_IRQ -1
#define SWITCHES_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SWITCHES_IRQ_TYPE "NONE"
#define SWITCHES_NAME "/dev/switches"
#define SWITCHES_RESET_VALUE 0
#define SWITCHES_SPAN 16
#define SWITCHES_TYPE "altera_avalon_pio"


/*
 * timer_0 configuration
 *
 */

#define ALT_MODULE_CLASS_timer_0 altera_avalon_timer
#define TIMER_0_ALWAYS_RUN 0
#define TIMER_0_BASE 0x2080
#define TIMER_0_COUNTER_SIZE 32
#define TIMER_0_FIXED_PERIOD 0
#define TIMER_0_FREQ 50000000
#define TIMER_0_IRQ 4
#define TIMER_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TIMER_0_LOAD_VALUE 49999
#define TIMER_0_MULT 0.001
#define TIMER_0_NAME "/dev/timer_0"
#define TIMER_0_PERIOD 1
#define TIMER_0_PERIOD_UNITS "ms"
#define TIMER_0_RESET_OUTPUT 0
#define TIMER_0_SNAPSHOT 1
#define TIMER_0_SPAN 32
#define TIMER_0_TICKS_PER_SEC 1000
#define TIMER_0_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_0_TYPE "altera_avalon_timer"


/*
 * timer_1 configuration
 *
 */

#define ALT_MODULE_CLASS_timer_1 altera_avalon_timer
#define TIMER_1_ALWAYS_RUN 0
#define TIMER_1_BASE 0x20a0
#define TIMER_1_COUNTER_SIZE 32
#define TIMER_1_FIXED_PERIOD 0
#define TIMER_1_FREQ 50000000
#define TIMER_1_IRQ 3
#define TIMER_1_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TIMER_1_LOAD_VALUE 49999
#define TIMER_1_MULT 0.001
#define TIMER_1_NAME "/dev/timer_1"
#define TIMER_1_PERIOD 1
#define TIMER_1_PERIOD_UNITS "ms"
#define TIMER_1_RESET_OUTPUT 0
#define TIMER_1_SNAPSHOT 1
#define TIMER_1_SPAN 32
#define TIMER_1_TICKS_PER_SEC 1000
#define TIMER_1_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_1_TYPE "altera_avalon_timer"


/*
 * to_external_bus_bridge_0 configuration
 *
 */

#define ALT_MODULE_CLASS_to_external_bus_bridge_0 altera_up_avalon_to_external_bus_bridge
#define TO_EXTERNAL_BUS_BRIDGE_0_BASE 0x4000000
#define TO_EXTERNAL_BUS_BRIDGE_0_IRQ 1
#define TO_EXTERNAL_BUS_BRIDGE_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TO_EXTERNAL_BUS_BRIDGE_0_NAME "/dev/to_external_bus_bridge_0"
#define TO_EXTERNAL_BUS_BRIDGE_0_SPAN 65536
#define TO_EXTERNAL_BUS_BRIDGE_0_TYPE "altera_up_avalon_to_external_bus_bridge"


/*
 * treble_out configuration
 *
 */

#define ALT_MODULE_CLASS_treble_out altera_avalon_pio
#define TREBLE_OUT_BASE 0x30
#define TREBLE_OUT_BIT_CLEARING_EDGE_REGISTER 0
#define TREBLE_OUT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define TREBLE_OUT_CAPTURE 0
#define TREBLE_OUT_DATA_WIDTH 4
#define TREBLE_OUT_DO_TEST_BENCH_WIRING 0
#define TREBLE_OUT_DRIVEN_SIM_VALUE 0
#define TREBLE_OUT_EDGE_TYPE "NONE"
#define TREBLE_OUT_FREQ 50000000
#define TREBLE_OUT_HAS_IN 0
#define TREBLE_OUT_HAS_OUT 1
#define TREBLE_OUT_HAS_TRI 0
#define TREBLE_OUT_IRQ -1
#define TREBLE_OUT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define TREBLE_OUT_IRQ_TYPE "NONE"
#define TREBLE_OUT_NAME "/dev/treble_out"
#define TREBLE_OUT_RESET_VALUE 0
#define TREBLE_OUT_SPAN 16
#define TREBLE_OUT_TYPE "altera_avalon_pio"

#endif /* __SYSTEM_H_ */
