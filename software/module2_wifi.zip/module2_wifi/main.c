#include <stdio.h>
#include <string.h>
#include "Wifi.h"


//char* isPlayingVal;
//char* currentStreamVal;

int main()
{
  printf("Hello from Nios II!\n");
  initWifi();
  printf("Finished Init_Wifi\n");
  dofile_server();
  waitWifi();
  getreply();


  waitWifi();
  waitWifi();

  char currStreamVal[] = "id";
  char isPlayingVal[] = "true";


  printf("%s,", isPlayingVal);
  printf("%s\n", currStreamVal);

  update_stream(isPlayingVal,currStreamVal);
  waitWifi();
// update_stream(isPlayingVal,currentStreamVal);

  //getreply();
  //getreply();
  //getreply();
  getlongreply(70);

  printf("done\n");
  return 0;
}

